import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import mpOne from '../assets/images/pages/mp-1.png'


const Opportunity = () => {

    const cardData = [
        {
          title: 'Main School Page',
          image: mpOne,
        },
        {
          title: 'Main School Page',
          image: mpOne,
        },
        {
          title: 'Main School Page',
          image: mpOne,
        },
        {
          title: 'Main School Page',
          image: mpOne,
        },
        {
          title: 'Main School Page',
          image: mpOne,
        },
        {
          title: 'Main School Page',
          image: mpOne,
        },
    ];

  return (
    <section className="job-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="subtitle">Search for job</h3>
                    <h2 className="sectionHeading">Job Opportunity</h2>
                </div>
            </div>
            <div className="row">
                {cardData.map((card, index) => (
                    
                    <div className="col-lg-4 col-md-4 col-sm-6 col-12">
                        <div className="pagCard">
                            <figure>
                                <img src={card.image} alt={card.title} className="img-fluid w-100" />
                            </figure>
                            <h3>{card.title}</h3>
                        </div>
                    </div>
                ))}

            </div>
        </div>
    </section>
  );
};

export default Opportunity;