import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import mapImg from '../assets/images/mapImg.png'

const Location = () => {

  return (
    <section className="map-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <h3 className="subtitle">MAP</h3>
                    <h2 className="sectionHeading">Google Map</h2>
                </div>
            </div>
            <div className="row">
                <div className="col-md-12">
                    <div className="mapCont">
                        <figure>
                            <img src={mapImg} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>                 
  );
};

export default Location;