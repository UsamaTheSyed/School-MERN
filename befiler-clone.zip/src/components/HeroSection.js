import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
// In src/index.js or src/App.js
import '@fortawesome/fontawesome-free/css/all.min.css';
import Bannerslider from "./Bannerslider";

import Girl from '../assets/images/girl.png'
import Level from '../assets/images/level.png'
import Page from '../assets/images/Page.png'
import Loc from '../assets/images/loc.png'


const HeroSection = () => {

  return (
    <div>
      <Bannerslider />

      <section className="schl-list-sect">
          <img src={Girl} alt="Consultants" className="img-fluid girl" />
          <div className="container">
              <div className="row">
                  <div className="col-md-12">
                      <h3 className="subtitle">List of schools</h3>
                      <h2 className="sectionHeading">Find your dream school</h2>
                  </div>
              </div>
              <div className="row justify-content-center">
                  <div className="col-md-10">
                      <div className="schlCont">
                          <form>
                              <div className="form-row align-items-center justify-content-between">
                                  <div className="col-md-3">
                                      <div className="input-group">
                                          <div className="input-group-prepend">
                                              <div className="input-group-text">
                                                  <img src={Level} alt="Consultants" className="img-fluid w-100" />
                                              </div>
                                          </div>
                                          <input type="text" className="form-control" id="inlineFormInputGroup"
                                              placeholder="School Name" />
                                      </div>
                                  </div>
                                  <div className="col-md-4">
                                      <div className="input-group center">
                                          <div className="input-group-prepend">
                                              <div className="input-group-text">
                                                  <img src={Page} alt="Consultants" className="img-fluid w-100" />
                                              </div>
                                          </div>
                                          <input type="text" className="form-control" id="inlineFormInputGroup"
                                              placeholder="Address of School" />
                                      </div>
                                  </div>
                                  <div className="col-md-3">
                                      <div className="input-group">
                                          <div className="input-group-prepend">
                                              <div className="input-group-text">
                                                  <img src={Loc} alt="Consultants" className="img-fluid w-100" />
                                              </div>
                                          </div>
                                          <input type="text" className="form-control" id="inlineFormInputGroup"
                                              placeholder="Location " />
                                      </div>
                                  </div>
                                  <div className="col-md-2">
                                      <button type="submit" className="themeBtn">Explore</button>
                                  </div>
                              </div>
                          </form>

                          <table>
                              <tbody>
                                  <tr>
                                      <th><span>1</span></th>
                                      <td>Abc School</td>
                                      <td>Abc Address</td>
                                      <td>Abc Address</td>
                                  </tr>

                                  <tr>
                                      <th><span>2</span></th>
                                      <td>Abc School</td>
                                      <td>Abc Address</td>
                                      <td>Abc Address</td>
                                  </tr>

                                  <tr>
                                      <th><span>3</span></th>
                                      <td>Abc School</td>
                                      <td>Abc Address</td>
                                      <td>Abc Address</td>
                                  </tr>

                                  <tr>
                                      <th><span>4</span></th>
                                      <td>Abc School</td>
                                      <td>Abc Address</td>
                                      <td>Abc Address</td>
                                  </tr>

                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </section>
    </div>
    
  );
};

export default HeroSection;
