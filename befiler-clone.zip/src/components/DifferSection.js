import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';


import Level from '../assets/images/level.png'
import Page from '../assets/images/Page.png'
import Dates from '../assets/images/date.png'
import frcImg from '../assets/images/frcImg.png'
import frcShape from '../assets/images/frcShape.png'
import mpOne from '../assets/images/pages/mp-1.png'



const DifferSection = () => {

  return (
    <section className="diff-sect">
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-4">
                    <div className="intros-chlCont">
                        <div className="schlCont">
                            <form>
                                <div className="form-row align-items-center justify-content-between">
                                    <div className="col-md-4">
                                        <div className="input-group">
                                            <div className="input-group-prepend">
                                                <div className="input-group-text">
                                                    <img src={Level} alt="Consultants" className="img-fluid" />
                                                </div>
                                            </div>
                                            <input type="text" className="form-control" id="inlineFormInputGroup"
                                                placeholder="School Name" />
                                        </div>
                                    </div>
                                    <div className="col-md-5">
                                        <div className="input-group center">
                                            <div className="input-group-prepend">
                                                <div className="input-group-text">
                                                    <img src={Page} alt="Consultants" className="img-fluid" />
                                                </div>
                                            </div>
                                            <input type="text" className="form-control" id="inlineFormInputGroup"
                                                placeholder="Address of School" />
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <button type="submit" className="themeBtn">Explore</button>
                                    </div>
                                </div>
                            </form>

                            <table>
                                <tbody>
                                    <tr>
                                        <th><span>1</span></th>
                                        <td>Abc School</td>
                                        <td>Abc Address</td>
                                        <td>Abc Address</td>
                                    </tr>

                                    <tr>
                                        <th><span>2</span></th>
                                        <td>Abc School</td>
                                        <td>Abc Address</td>
                                        <td>Abc Address</td>
                                    </tr>

                                    <tr>
                                        <th><span>3</span></th>
                                        <td>Abc School</td>
                                        <td>Abc Address</td>
                                        <td>Abc Address</td>
                                    </tr>

                                    <tr>
                                        <th><span>4</span></th>
                                        <td>Abc School</td>
                                        <td>Abc Address</td>
                                        <td>Abc Address</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                        <div className="intros-chlCont">
                            <div className="schlCont">
                                <form>
                                    <div className="form-row align-items-center justify-content-between">
                                        <div className="col-md-4">
                                            <div className="input-group">
                                                <div className="input-group-prepend">
                                                    <div className="input-group-text">
                                                        <img src={Level} alt="Consultants" className="img-fluid" />
                                                    </div>
                                                </div>
                                                <input type="text" className="form-control" id="inlineFormInputGroup"
                                                    placeholder="Enter the Name" />
                                            </div>
                                        </div>
                                        <div className="col-md-5">
                                            <div className="input-group">
                                                <div className="input-group-prepend">
                                                    <div className="input-group-text">
                                                        <img src={Dates} alt="Consultants" className="img-fluid" />
                                                    </div>
                                                </div>
                                                <input type="text" className="form-control" id="inlineFormInputGroup"
                                                    placeholder="Choose Date " />
                                            </div>
                                        </div>
                                        <div className="col-md-3">
                                            <button type="submit" className="themeBtn">Explore</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <p><i className="fas fa-star"></i> 1st Friend ship scout in Karachi Gulshan e Iqbal
                                organized by PPSA</p>

                            <div className="frCard">
                                <figure>
                                    <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                    <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                    <div className="overlay">
                                        <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                            Jan 16, 2024</a>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="frCont mt-5">
                        <figure>
                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                        </figure>
                        <ul>
                            <li><a href="javascript:;"><i className="fas fa-thumbs-up"></i></a></li>
                            <li><a href="javascript:;"><i className="fas fa-share-alt"></i></a></li>
                            <li><a href="javascript:;"><i className="fas fa-comment-lines"></i></a></li>
                        </ul>
                    </div>
                    <div className="frCont mt-5">
                        <figure>
                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                        </figure>
                        <ul>
                            <li><a href="javascript:;"><i className="fas fa-thumbs-up"></i></a></li>
                            <li><a href="javascript:;"><i className="fas fa-share-alt"></i></a></li>
                            <li><a href="javascript:;"><i className="fas fa-comment-lines"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="pagCard mainPg">
                        <figure>
                            <img src={mpOne} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default DifferSection;