import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';


import glTop from '../assets/images/gl-top-shape.png'
import glBottom from '../assets/images/gl-bottom-shape.png'
import Mask from '../assets/images/mask.png' 
import Masktwo from '../assets/images/mask-2.png' 
import Compass from '../assets/images/compass.png' 
import Pencil from '../assets/images/pencil.png' 
import eviOne from '../assets/images/evi-1.png'
import eviTwo from '../assets/images/evi-2.png'
import eviThree from '../assets/images/evi-3.png'

const Event = () => {


    const cardData = [
        {
          title: 'Kindergarten',
          year: '(4-5 years)',
          description: 'Lorem ipsum dolor consectur the adipiscing elit eiusmod.',
          image: eviOne,
          buttonText: '<i className="fal fa-long-arrow-right"></i>',
          className: 'one'
        },
        {
          title: 'Kindergarten',
          year: '(4-5 years)',
          description: 'Lorem ipsum dolor consectur the adipiscing elit eiusmod.',
          image: eviTwo,
          buttonText: '<i className="fal fa-long-arrow-right"></i>',
          className: 'two'
        },
        {
          title: 'Kindergarten',
          year: '(4-5 years)',
          description: 'Lorem ipsum dolor consectur the adipiscing elit eiusmod.',
          image: eviThree,
          buttonText: '<i className="fal fa-long-arrow-right"></i>',
          className: 'three'
        },
    ];

  return (

    <section className="event-sect">

        <img src={glTop} alt="Consultants" className="img-fluid gl-top-shape" />
        <img src={glBottom} alt="Consultants" className="img-fluid gl-bottom-shape" />
        <img src={Mask} alt="Consultants" className="img-fluid mask" />
        <img src={Masktwo} alt="Consultants" className="img-fluid masktwo" />
        <img src={Compass} alt="Consultants" className="img-fluid compass" />
        <img src={Pencil} alt="Consultants" className="img-fluid pencil" />

        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="subtitle">Events</h3>
                    <h2 className="sectionHeading">PICS of school Events</h2>
                </div>
            </div>
            <div className="row">

                {cardData.map((card, index) => (
                    <div className="col-md-4">
                        <div className="evCard three">
                            <figure>
                                <img src={card.image} alt={card.title} className="img-fluid w-100" />
                            </figure>
                            <h3>{card.title}</h3>
                            <h5>{card.year}</h5>
                            <p>{card.description}</p>
                            <a href="javascript:;" className="evBtn">{card.buttonText}</a>
                        </div>
                    </div>
                ))}
                
            </div>
        </div>
    </section>  
  );
};

export default Event;