import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import frcImg from '../assets/images/frcImg.png'
import frcShape from '../assets/images/frcShape.png'
import level from '../assets/images/level.png'
import date from '../assets/images/date.png'
import BlogTwo from '../assets/images/blg-2.png'
import Resume from '../assets/images/resume.png'
import SrcOne from '../assets/images/src-1.png'
import SrcTwo from '../assets/images/src-2.png'

const FractionSection = () => {

  return (
    <div>
        <section className="frc-sect">
            <div className="container">
                <div className="row">
                    <div className="col-md-4">
                        <div className="frCont">
                            <figure>
                                <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                            </figure>
                            <ul>
                                <li><a href="javascript:;"><i className="fas fa-thumbs-up"></i></a></li>
                                <li><a href="javascript:;"><i className="fas fa-share-alt"></i></a></li>
                                <li><a href="javascript:;"><i className="fas fa-comment-lines"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-md-8">
                        <div className="frContent">
                            <div className="row">
                                <div className="col-md-10">
                                    <div className="schlCont">
                                        <form>
                                            <div className="form-row align-items-center justify-content-between">
                                                <div className="col-md-4">
                                                    <div className="input-group">
                                                        <div className="input-group-prepend">
                                                            <div className="input-group-text">
                                                                <img src={level} alt="Consultants" className="img-fluid" />
                                                            </div>
                                                        </div>
                                                        <input type="text" className="form-control" id="inlineFormInputGroup"
                                                            placeholder="Enter the Name" />
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="input-group">
                                                        <div className="input-group-prepend">
                                                            <div className="input-group-text">
                                                                <img src={date} alt="Consultants" className="img-fluid" />
                                                            </div>
                                                        </div>
                                                        <input type="text" className="form-control" id="inlineFormInputGroup"
                                                            placeholder="Choose Date " />
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <button type="submit" className="themeBtn">Explore</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div className="row mt-3">
                                <div className="col-md-12">
                                    <p><i className="fas fa-star"></i> 1st Friend ship scout in Karachi Gulshan e Iqbal
                                        organized by PPSA</p>
                                </div>

                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="col-md-12">
                                    <p><i className="fas fa-star"></i> 1st Friend ship scout in Karachi Gulshan e Iqbal
                                        organized by PPSA</p>
                                </div>

                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="col-md-12">
                                    <p><i className="fas fa-star"></i> 1st Friend ship scout in Karachi Gulshan e Iqbal
                                        organized by PPSA</p>
                                </div>

                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="frCard">
                                        <figure>
                                            <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                            <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                            <div className="overlay">
                                                <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                                    Jan 16, 2024</a>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section className="friend-sect">
            <div className="container">
                <div className="row">
                    <div className="col-md-12 text-center">
                        <h3 className="subtitle">Our Friends</h3>
                        <h2 className="sectionHeading">Meet with our Friends</h2>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6">
                        <div className="blgCard blgFlex">
                            <figure>
                                <img src={BlogTwo} alt="Consultants" className="img-fluid w-100" />
                            </figure>
                            <div className="blgBody">
                                <ul>
                                    <li><a href="javascript:;"><i className="fas fa-tag"></i> Cooking</a></li>
                                    <li><a href="javascript:;"><i className="fas fa-calendar-alt"></i> Feb 20, 2024</a></li>
                                </ul>
                                <h3><a href="javascript:;">School Name / Friend Name</a></h3>
                                <p>
                                    Nulla a auctor leo. Vestibulum viverra mattis arcunec viverra. Vivamus Nulla a auctor
                                    leo. Vestibulum viverra mattis arcunec viverra. Vivamus
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="blgCard blgFlex">
                            <figure>
                                <img src={BlogTwo} alt="Consultants" className="img-fluid w-100" />
                            </figure>
                            <div className="blgBody">
                                <ul>
                                    <li><a href="javascript:;"><i className="fas fa-tag"></i> Cooking</a></li>
                                    <li><a href="javascript:;"><i className="fas fa-calendar-alt"></i> Feb 20, 2024</a></li>
                                </ul>
                                <h3><a href="javascript:;">School Name / Friend Name</a></h3>
                                <p>
                                    Nulla a auctor leo. Vestibulum viverra mattis arcunec viverra. Vivamus Nulla a auctor
                                    leo. Vestibulum viverra mattis arcunec viverra. Vivamus
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section className="resume-sect">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <h2 className="sectionHeading">My Blog</h2>
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-6">
                        <figure>
                            <img src={Resume} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                    </div>
                    <div className="col-md-6">
                        <figure>
                            <img src={SrcOne} alt="Consultants" className="img-fluid" />
                        </figure>
                        <figure>
                            <img src={SrcTwo} alt="Consultants" className="img-fluid" />
                        </figure>
                    </div>
                </div>
            </div>
        </section>
    </div>
  );
};

export default FractionSection;