import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import Cloud from '../assets/images/cloud.png'
import Frame from '../assets/images/frame.png'
import Love from '../assets/images/love.png'
import Teamshape from '../assets/images/team-shape.png'
import techOne from '../assets/images/tech-1.png'
import techTwo from '../assets/images/tech-2.png'
import techThree from '../assets/images/tech-3.png'
import techFour from '../assets/images/tech-4.png'

const TeamTwo = () => {

    const settings = {
        dots: false,             
        infinite: true,         
        speed: 500,             
        slidesToShow: 4,        
        slidesToScroll: 1,      
        autoplay: true,         
        autoplaySpeed: 2000,
        arrows: false,  
    };

  return (
    <section class="team-sect">
        <img src={Cloud} alt="Consultants" className="img-fluid cloud" />
        <img src={Frame} alt="Consultants" className="img-fluid frame" />
        <img src={Love} alt="Consultants" className="img-fluid love" />
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <h3 class="subtitle">Best Teachers</h3>
                    <h2 class="sectionHeading">Teachers or the month</h2>
                </div>
                <div class="col-md-5">
                    <div class="tmsldBtn">
                        <button class="btn tmPrev"><i class="fal fa-arrow-left"></i></button>
                        <button class="btn tmNext"><i class="fal fa-arrow-right"></i></button>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="teamSlider slick-slider-container">
                        <Slider {...settings}>
                            <div class="teamCrad">
                                <figure>
                                    <img src={techOne} alt="Consultants" className="img-fluid" />
                                    <img src={Teamshape} alt="Consultants" className="img-fluid team-shape" />
                                </figure>
                                <div class="data">
                                    <h3>Sohail Sardar</h3>
                                    <p>Instructors</p>
                                </div>
                            </div>
                            <div class="teamCrad">
                                <figure>
                                    <img src={techTwo} alt="Consultants" className="img-fluid" />
                                    <img src={Teamshape} alt="Consultants" className="img-fluid team-shape" />      
                                </figure>
                                <div class="data">
                                    <h3>Sohail Sardar</h3>
                                    <p>Instructors</p>
                                </div>
                            </div>
                            <div class="teamCrad">
                                <figure>
                                    <img src={techThree} alt="Consultants" className="img-fluid" />
                                    <img src={Teamshape} alt="Consultants" className="img-fluid team-shape" />
                                </figure>
                                <div class="data">
                                    <h3>Sohail Sardar</h3>
                                    <p>Instructors</p>
                                </div>
                            </div>
                            <div class="teamCrad">
                                <figure>
                                    <img src={techFour} alt="Consultants" className="img-fluid" />
                                    <img src={Teamshape} alt="Consultants" className="img-fluid team-shape" />
                                </figure>
                                <div class="data">
                                    <h3>Sohail Sardar</h3>
                                    <p>Instructors</p>
                                </div>
                            </div>
                            <div class="teamCrad">
                                <figure>
                                    <img src={techTwo} alt="Consultants" className="img-fluid" />
                                    <img src={Teamshape} alt="Consultants" className="img-fluid team-shape" />
                                </figure>
                                <div class="data">
                                    <h3>Sohail Sardar</h3>
                                    <p>Instructors</p>
                                </div>
                            </div>
                        </Slider>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default TeamTwo;