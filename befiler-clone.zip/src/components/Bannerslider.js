import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
// In src/index.js or src/App.js
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import banBg from '../assets/images/bans-1.png';
import bantwoBg from '../assets/images/bans-2.png';
import Parasuit from '../assets/images/parasuit.png';
import starTwo from '../assets/images/star-2.png';
import Doll from '../assets/images/doll.png';
import Bus from '../assets/images/bus.png';
import beeTwo from '../assets/images/bee-2.png';

const Bannerslider = () => {
  const settings = {
    dots: false,             
    infinite: true,         
    speed: 500,             
    slidesToShow: 1,        
    slidesToScroll: 1,      
    autoplay: true,         
    autoplaySpeed: 2000,    
  };
  return (
    <section className="mainBanner" id="">
        <div className="container-fluid p-0">
            <div className="row m-0">
                <div className="col-md-12 p-0">
                    <div className="banCont">
                          <div className="banSlider slick-slider-container">
                          <Slider {...settings}>
                                <figure>
                                    <img src={banBg} alt="Consultants" className="img-fluid w-100" />
                                    <div className="overlay">
                                        <img src={Parasuit} alt="Consultants" className="img-fluid parasuit" />
                                        <img src={starTwo} alt="Consultants" className="img-fluid star-2" />
                                        <img src={Doll} alt="Consultants" className="img-fluid doll" />
                                        <img src={Bus} alt="Consultants" className="img-fluid bus" />
                                        <img src={beeTwo} alt="Consultants" className="img-fluid bee-2" />
                                        <h3>Welcome to Kidsa</h3>
                                        <h1>Here are <span>List of <br /> Schools.</span></h1>
                                        <p>
                                            Suspendisse eget lectus vitae elit malesuada lacinia Vestibulum<br />
                                            scelerisque, ligula sit amet consequat
                                        </p>
                                        <div className="headRight">
                                            <a href="javascript:;" className="themeBtn">Explore More <i
                                                    className="fal fa-long-arrow-right"></i></a>
                                            <a href="javascript:;" className="themeBtn">get A Quote <i
                                                    className="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </figure>

                                <figure>
                                    <img src={bantwoBg} alt="Consultants" className="img-fluid w-100" />
                                    <div className="overlay">
                                        <img src={Parasuit} alt="Consultants" className="img-fluid parasuit" />
                                        <img src={starTwo} alt="Consultants" className="img-fluid star-2" />
                                        <img src={Doll} alt="Consultants" className="img-fluid doll" />
                                        <img src={Bus} alt="Consultants" className="img-fluid bus" />
                                        <img src={beeTwo} alt="Consultants" className="img-fluid bee-2" />
                                        <h3>Welcome to Kidsa</h3>
                                        <h1>Here are <span>List of <br /> Schools.</span></h1>
                                        <p>
                                            Suspendisse eget lectus vitae elit malesuada lacinia Vestibulum<br />
                                            scelerisque, ligula sit amet consequat
                                        </p>
                                        <div className="headRight">
                                            <a href="javascript:;" className="themeBtn">Explore More <i
                                                    className="fal fa-long-arrow-right"></i></a>
                                            <a href="javascript:;" className="themeBtn">get A Quote <i
                                                    className="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </figure>
                          </Slider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default Bannerslider;
