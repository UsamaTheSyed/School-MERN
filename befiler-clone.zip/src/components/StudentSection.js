import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import Level from '../assets/images/level.png'
import Dates from '../assets/images/date.png'
import StudOne from '../assets/images/stu-1.png'
import stuShape from '../assets/images/stu-shape.png'



const StudentSection = () => {

    const cardData = [
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
        {
          name: 'Brooklyn Simmons',
          position: 'POSITION 1',
          image: StudOne,
          shape: stuShape,
          class: 'Class 1'
        },
    ];


  return (
    <section className="student-sect">
        <div className="container">
            <div className="row align-items-center">
                <div className="col-md-7">
                    <h2 className="sectionHeading">Ready for Jobs</h2>
                </div>
                <div className="col-md-5">
                    <div className="intros-chlCont">
                        <div className="schlCont">
                            <form>
                                <div className="form-row align-items-center justify-content-between">
                                    <div className="col-md-4">
                                        <div className="input-group">
                                            <div className="input-group-prepend">
                                                <div className="input-group-text">
                                                    <img src={Level} alt="Consultants" className="img-fluid" />
                                                </div>
                                            </div>
                                            <input type="text" className="form-control" id="inlineFormInputGroup"
                                                placeholder="Enter the Name" />
                                        </div>
                                    </div>
                                    <div className="col-md-5">
                                        <div className="input-group">
                                            <div className="input-group-prepend">
                                                <div className="input-group-text">
                                                    <img src={Dates} alt="Consultants" className="img-fluid" />
                                                </div>
                                            </div>
                                            <input type="text" className="form-control" id="inlineFormInputGroup"
                                                placeholder="Choose Date " />
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <button type="submit" className="themeBtn">Explore</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
            <div className="row">
                {cardData.map((card, index) => (
                    <div className="col-lg-3 col-md-4 col-sm-6 col-12">
                        <div className="stuCard">
                            <figure>
                                <img src={card.image} alt={card.title} className="img-fluid w-100" />
                                <img src={card.shape} alt={card.title} className="img-fluid stu-shape" />
                            </figure>
                            <h3>{card.position}</h3>
                            <h4>{card.name}</h4>
                            <p>{card.class}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </section>
    
  );
};

export default StudentSection;