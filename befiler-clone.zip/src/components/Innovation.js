import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import GalOne from '../assets/images/gl-1.png'
import GalTwo from '../assets/images/gl-2.png'
import GalThree from '../assets/images/gl-3.png'
import GalFour from '../assets/images/gl-4.png'
import GalFive from '../assets/images/gl-5.png'
import GalSix from '../assets/images/gl-6.png'

const Innovation = () => {

  return (
    <section className="innov-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="subtitle">Innovations</h3>
                    <h2 className="sectionHeading">Students Innovations</h2>
                </div>
            </div>
            <div className="row">
                <div className="col-md-4">
                    <div className="gal">
                        <figure>
                            <img src={GalOne} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <figure>
                            <img src={GalTwo} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="gal">
                        <figure>
                            <img src={GalThree} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <figure>
                            <img src={GalFour} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="gal">
                        <figure>
                            <img src={GalFive} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <figure>
                            <img src={GalSix} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default Innovation;