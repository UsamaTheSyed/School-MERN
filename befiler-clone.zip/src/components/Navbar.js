import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Nav, Navbar, Button } from 'react-bootstrap';
// import logo from '../assets/images/logo.png'; // your logo
// import usaIcon from '../assets/images/usa-flag.png'; // usa icon

const MegaMenu = () => {
  return (
    <div className="mega-menu-full position-absolute start-0 bg-white shadow p-4">
      <div className="container">
        <div className="row">
          <div className="col-md-3">
            <h6 className="text-uppercase fw-bold">Filing</h6>
            <ul className="list-unstyled">
              <li><a href="#">Personal Tax Filing</a></li>
              <li><a href="#">Business Tax Filing</a></li>
              <li><a href="#">Sales Tax Filing</a></li>
            </ul>
          </div>
          <div className="col-md-3">
            <h6 className="text-uppercase fw-bold">Registration</h6>
            <ul className="list-unstyled">
              <li><a href="#">Company Registration</a></li>
              <li><a href="#">Trademark Registration</a></li>
              <li><a href="#">LLC Setup</a></li>
            </ul>
          </div>
          <div className="col-md-3">
            <h6 className="text-uppercase fw-bold">Support</h6>
            <ul className="list-unstyled">
              <li><a href="#">Consult a Tax Expert</a></li>
              <li><a href="#">Live Chat</a></li>
              <li><a href="#">Help Center</a></li>
            </ul>
          </div>
          <div className="col-md-3">
            <h6 className="text-uppercase fw-bold">Tools</h6>
            <ul className="list-unstyled">
              <li><a href="#">Tax Calculator</a></li>
              <li><a href="#">Income Estimator</a></li>
              <li><a href="#">Refund Tracker</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

const CustomNavbar = () => {
  return (
    <Navbar expand="lg" className="py-3 border-bottom bg-white position-relative">
      <Container>
        <Navbar.Brand href="/">
          {/* <img src={logo} alt="Befiler Logo" height="40" /> */}
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="main-navbar" />

        <Navbar.Collapse id="main-navbar">
          <Nav className="mx-auto fw-bold gap-4">
            <Nav.Link href="#">TAX TOOLS</Nav.Link>

            <div className="nav-item dropdown position-static">
              <Nav.Link
                href="#"
                className="dropdown-toggle"
                id="businessDropdown"
                role="button"
              >
                BUSINESS SERVICES
              </Nav.Link>
              <MegaMenu />
            </div>

            <Nav.Link href="#">SALES TAX</Nav.Link>

            <Nav.Link href="#" className="text-danger d-flex align-items-center gap-1">
              {/* <img src={usaIcon} alt="USA Icon" width="20" /> */}
              USA SERVICES
            </Nav.Link>
          </Nav>

          <div className="d-flex gap-2">
            <Button variant="outline-danger">Sign up</Button>
            <Button variant="danger">
              <i className="bi bi-lock-fill me-1"></i> Sign in
            </Button>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default CustomNavbar;
