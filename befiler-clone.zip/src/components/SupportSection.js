import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import logoOne from '../assets/images/lg-1.png'
import logoTwo from '../assets/images/lg-2.png'
import logoThree from '../assets/images/lg-3.png'
import logoFour from '../assets/images/lg-4.png'
import logoFive from '../assets/images/lg-5.png'


const SupportSection = () => {

    const settings = {
        dots: false,
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 1,
        arrows: false,
        variablewidth: true,
        centerMode: true,   
    };

  return (
    <section className="support-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div className="supCont">
                        <h4>Our Support</h4>
                    </div>
                    <div className="supSliderOne">
                        <Slider {...settings}>
                            <figure><img src={logoOne} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoTwo} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoThree} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoFour} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoFive} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoOne} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoTwo} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoThree} alt="Consultants" className="img-fluid" /></figure>
                        </Slider>
                    </div>

                    <div class="supSliderOne">
                        <Slider {...settings}>
                            <figure><img src={logoOne} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoTwo} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoThree} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoFour} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoFive} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoOne} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoTwo} alt="Consultants" className="img-fluid" /></figure>
                            <figure><img src={logoThree} alt="Consultants" className="img-fluid" /></figure>
                        </Slider>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default SupportSection;