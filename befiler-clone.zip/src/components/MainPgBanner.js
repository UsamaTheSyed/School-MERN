import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';


import oppBottom from '../assets/images/oppBottom.png'
import Parasuit from '../assets/images/parasuit.png';
import starTwo from '../assets/images/star-2.png';
import beeTwo from '../assets/images/bee-2.png';
import left from '../assets/images/left.png';
import book from '../assets/images/book.png';
import pencil from '../assets/images/pencil.png';
import right from '../assets/images/right.png';
import welBg from '../assets/images/oppBg.png';

const MainPgBanner = () => {

  return (
    <div>
        <section class="mainBanner" id="">
            <img src={oppBottom} alt="Consultants" className="img-fluid oppBottom" />
            <div class="container-fluid p-0">
                <div class="row m-0">
                    <div class="col-md-12 p-0">
                        <div class="jobCont">
                            <div class="banSlider">
                                <figure>
                                    <img src={welBg} alt="Consultants" className="img-fluid w-100" />
                                    <div class="overlay">
                                        <img src={Parasuit} alt="Consultants" className="img-fluid parasuit" />
                                        <img src={starTwo} alt="Consultants" className="img-fluid star-2" />
                                        <img src={beeTwo} alt="Consultants" className="img-fluid bee-2" />
                                        <img src={left} alt="Consultants" className="img-fluid left" />
                                        <img src={book} alt="Consultants" className="img-fluid book" />
                                        <img src={pencil} alt="Consultants" className="img-fluid pencil" />
                                        <img src={right} alt="Consultants" className="img-fluid right" />
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section className="not-sect">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <h3>Notice: Let Us Know About Our Reading And Cultural</h3>
                    </div>
                </div>
            </div>
        </section>
    </div>
        
  );
};

export default MainPgBanner;