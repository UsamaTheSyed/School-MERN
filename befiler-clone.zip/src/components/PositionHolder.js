import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import holdImg from '../assets/images/holdImg.png'

const PositionHolder = () => {

    const settings = {
        dots: false,             
        infinite: true,         
        speed: 500,             
        slidesToShow: 4,        
        slidesToScroll: 1,      
        autoplay: true,         
        autoplaySpeed: 2000,    
    };

    const cardData = [
        {
          name: 'Ronald Richards',
          position: 'Position no. 1',
          class: 'Class 1',
          image: holdImg,
        },
        {
            name: 'Ronald Richards',
            position: 'Position no. 1',
            class: 'Class 1',
            image: holdImg,
        },
        {
          name: 'Ronald Richards',
          position: 'Position no. 1',
          class: 'Class 1',
          image: holdImg,
        },
        {
          name: 'Ronald Richards',
          position: 'Position no. 1',
          class: 'Class 1',
          image: holdImg,
        },
        {
          name: 'Ronald Richards',
          position: 'Position no. 1',
          class: 'Class 1',
          image: holdImg,
        },
    ];

  return (
    <section className="holder-sect">
        <div className="container-fluid p-0">
            <div className="row m-0 justify-content-center align-items-center">
                <div className="col-md-5 p-0">
                    <h3 className="subtitle">Holders</h3>
                    <h2 className="sectionHeading">Position Holder Students</h2>
                </div>
                <div className="col-md-5 p-0">
                    <div className="headRight">
                        <a href="javascript:;" className="themeBtn">See All<i className="fal fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div className="row m-0">
                <div className="col-md-12 p-0">
                    <div className="holdSlider">
                        <Slider {...settings}>

                            {cardData.map((card, index) => (
                                <div className="holCard">
                                    <figure>
                                        <img src={card.image} alt={card.name} className="img-fluid w-100" />
                                    </figure>
                                    <h3>{card.name}</h3>
                                    <h4>{card.position}</h4>
                                    <p>{card.class}</p>
                                </div>
                            ))}
                        </Slider>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default PositionHolder;