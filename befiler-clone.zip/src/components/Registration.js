import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

const Registration = () => {

  return (
    <section class="regis-sect">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-7">
                    <div class="regForm">
                        <h3>Sign Up Here</h3>
                        <form>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <input type="text" class="form-control" id="name" placeholder="Name*" />
                                </div>
                                <div class="form-group col-md-6">
                                    <input type="email" class="form-control" id="email" placeholder="Email*" />
                                </div>
                                <div class="form-group col-md-6">
                                    <input type="password" class="form-control" id="Pass" placeholder="Password*" />
                                </div>
                                <div class="form-group col-md-6">
                                    <input type="password" class="form-control" id="confirm-pass"
                                        placeholder="Conform Password*" />
                                </div>

                                <div class="form-group col-md-6">
                                    <input type="text" class="form-control" id="phone" placeholder="Phone Number*" />
                                </div>
                                <div class="form-group col-md-6">
                                    <select id="inputState" class="form-control">
                                        <option selected>Type</option>
                                        <option>School</option>
                                        <option>Student</option>
                                        <option>Parent</option>
                                        <option>Other</option>
                                    </select>
                                </div>
                            </div>

                            <div class="formSign headRight">
                                <a href="/Login" class="themeBtn">Login</a>
                                <button type="submit" class="themeBtn">Register</button>
                            </div>
                            <ul>
                                <li><a href="javascript:;"><i class="fab fa-google"></i></a></li>
                                <li><a href="javascript:;"><i class="fab fa-facebook-f"></i></a></li>
                            </ul>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>                
  );
};

export default Registration;