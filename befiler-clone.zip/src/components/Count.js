import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import ctOne from '../assets/images/ct-1.png'
import ctTwo from '../assets/images/ct-2.png'
import ctThree from '../assets/images/ct-3.png'


const Count = () => {


  return (
    <section className="count-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-4">
                    <div className="countCard">
                        <div className="number">50+</div>
                        <figure>
                            <img src={ctOne} alt="Consultants" className="img-fluid" />
                        </figure>
                        <h4>50+</h4>
                        <p>Number of Staff</p>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="countCard numTwo">
                        <div className="number">70+</div>
                        <figure>
                            <img src={ctTwo} alt="Consultants" className="img-fluid" />
                        </figure>
                        <h4>70+</h4>
                        <p>Number of Staff</p>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="countCard">
                        <div className="number">900</div>
                        <figure>
                            <img src={ctThree} alt="Consultants" className="img-fluid" />
                        </figure>
                        <h4>900</h4>
                        <p>Number of Staff</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default Count;