import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
// import { images } from "./Cardimages";

const PartnerSection = () => {
  return (
    <section className="PartSect py-5">
      <div className="container">
        <div className="row align-items-center">
          {/* Text Column */}
          <div className="col-lg-12 mb-4 mb-lg-0">
            <h2 className="fw-bold text-danger mb-3 text-center" style={{ fontSize: "2.25rem" }}>
                Our Partners & Collaborators
            </h2>
          </div>

          {/* Image Column */}
          <div className="col-lg-12 text-center py-5">
            {/* <div className="partImgs">
              {images.map((PartnerSection) => (
                <figure>
                  <img
                    src={PartnerSection.image} alt={PartnerSection.title}
                    className="img-fluid"
                    />
                </figure>
              ))}
            </div> */}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnerSection;
