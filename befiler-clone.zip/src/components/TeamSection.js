import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import Cloud from '../assets/images/cloud.png'
import Frame from '../assets/images/frame.png'
import Love from '../assets/images/love.png'
import TeamOne from '../assets/images/tm-1.png'
import TeamTwo from '../assets/images/tm-2.png'
import TeamThree from '../assets/images/tm-3.png'
import TeamFour from '../assets/images/tm-4.png'
import TeamShape from '../assets/images/team-shape.png'


const TeamSection = () => {


  const settings = {
    dots: false,             
    infinite: true,         
    speed: 500,             
    slidesToShow: 4,        
    slidesToScroll: 1,      
    autoplay: false,         
    autoplaySpeed: 2000,    
    arrows: false
  };


  return (
   
    <section className="team-sect">
      <img src={Cloud} alt="Consultants" className="img-fluid cloud" />
      <img src={Frame} alt="Consultants" className="img-fluid frame" />
      <img src={Love} alt="Consultants" className="img-fluid love" />
      <div className="container">
          <div className="row align-items-center">
              <div className="col-md-7">
                  <h3 className="subtitle">About</h3>
                  <h2 className="sectionHeading">our People and Leadership</h2>
              </div>
              <div className="col-md-5">
                  <div className="tmsldBtn">
                      <button className="btn tmPrev"><i className="fal fa-arrow-left"></i></button>
                      <button className="btn tmNext"><i className="fal fa-arrow-right"></i></button>
                  </div>
              </div>
          </div>
          <div className="row">
              <div className="col-md-12">
                  <div className="teamSlider">
                      <Slider {...settings}>
                        <div className="teamCrad">
                            <figure>
                                <img src={TeamOne} alt="Consultants" className="img-fluid" />
                                <img src={TeamShape} alt="Consultants" className="img-fluid team-shape" />
                            </figure>
                            <div className="data">
                                <h3>Sohail Sardar</h3>
                                <p>CEO</p>
                                <ul>
                                    <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-twitter"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="teamCrad">
                            <figure>
                                <img src={TeamTwo} alt="Consultants" className="img-fluid" />
                                <img src={TeamShape} alt="Consultants" className="img-fluid team-shape" />
                            </figure>
                            <div className="data">
                                <h3>Sohail Sardar</h3>
                                <p>CEO</p>
                                <ul>
                                    <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-twitter"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="teamCrad">
                            <figure>
                                <img src={TeamThree} alt="Consultants" className="img-fluid" />
                                <img src={TeamShape} alt="Consultants" className="img-fluid team-shape" />
                            </figure>
                            <div className="data">
                                <h3>Sohail Sardar</h3>
                                <p>CEO</p>
                                <ul>
                                    <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-twitter"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="teamCrad">
                            <figure>
                                <img src={TeamFour} alt="Consultants" className="img-fluid" />
                                <img src={TeamShape} alt="Consultants" className="img-fluid team-shape" />
                            </figure>
                            <div className="data">
                                <h3>Sohail Sardar</h3>
                                <p>CEO</p>
                                <ul>
                                    <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-twitter"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="teamCrad">
                            <figure>
                                <img src={TeamTwo} alt="Consultants" className="img-fluid" />
                                <img src={TeamShape} alt="Consultants" className="img-fluid team-shape" />
                            </figure>
                            <div className="data">
                                <h3>Sohail Sardar</h3>
                                <p>CEO</p>
                                <ul>
                                    <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-twitter"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="javascript:;"><i className="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                      </Slider>
                  </div>
              </div>
          </div>
        </div>
    </section>
  );
};

export default TeamSection;