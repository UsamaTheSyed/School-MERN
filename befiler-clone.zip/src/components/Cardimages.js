// import part1 from '../assets/images/stImg-1.png';
// import part2 from '../assets/images/stImg-1.png';

// export const images = [
//     { id: 1, image: part1},
//     { id: 2, image: part2},
//   ];