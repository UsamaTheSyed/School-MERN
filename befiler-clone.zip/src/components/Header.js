import React from "react";
import { Navbar, Nav, Button, Container } from 'react-bootstrap';
// import MegaMenu from './MegaMenu'; 
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import Logo from '../assets/images/logo.png'
import Grid from '../assets/images/grid.png'

const Header = () => {
  return (
    <header className="header" id="myHeader">
      <div className="Headpart-1">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="nav-1">
                <ul>
                  <li><a href="#"><i className="fal fa-map-marker-alt"></i> 0001 Pak St. Celina, PAK</a></li>
                  <li><a href="#"><i className="fal fa-envelope"></i> info@example.com</a></li>
                </ul>
              </div>
            </div>
            <div className="col-md-6">
              <div className="nav-2">
                <h4>Follow Us On:</h4>
                <ul>
                  <li><a href="#"><i className="fab fa-facebook-f"></i></a></li>
                  <li><a href="#"><i className="fab fa-twitter"></i></a></li>
                  <li><a href="#"><i className="fab fa-linkedin-in"></i></a></li>
                  <li><a href="#"><i className="fab fa-youtube"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="Headpart-2">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-2">
              <div className="logoDiv">
                <div className="logo">
                  <a href="#">
                    <figure>
                      <img src={Logo} alt="Consultants" className="img-fluid" />
                    </figure>
                  </a>
                </div>
                <div className="catgBtn">
                  <div className="dropdown">
                    <button
                      className="btn btn-secondary dropdown-toggle"
                      type="button"
                      data-toggle="dropdown"
                      aria-expanded="false"
                    >
                      <span>
                        <figure>
                            <img src={Grid} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                      </span>
                      Category
                    </button>
                    <div className="dropdown-menu">
                      <a className="dropdown-item" href="#">Category</a>
                      <a className="dropdown-item" href="#">Category</a>
                      <a className="dropdown-item" href="#">Category</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-8">
              <div className="navigation">
                <Navbar expand="lg" className="py-3 position-relative">
                    <Container>
                        <Navbar.Brand href="/">
                        {/* <img src={logo} alt="Befiler Logo" height="40" /> */}
                        </Navbar.Brand>

                        <Navbar.Toggle aria-controls="main-navbar" />
                        <Navbar.Collapse id="main-navbar">
                            <Nav className="mx-auto fw-bold">
                                <Nav.Link href="/">List of school</Nav.Link>

                                {/* <div className="nav-item dropdown position-static">
                                <Nav.Link
                                    href="#"
                                    className="dropdown-toggle"
                                    id="businessDropdown"
                                    role="button"
                                >
                                    BUSINESS SERVICES
                                </Nav.Link>
                                <MegaMenu />
                                </div> */}

                                <Nav.Link href="/StarStudents">Star Students</Nav.Link>
                                <Nav.Link href="/FinalSchool">School</Nav.Link>
                                <Nav.Link href="/Chairman">Chairman</Nav.Link>
                                <Nav.Link href="/WelcomePage">Welcome to school</Nav.Link>
                                <Nav.Link href="/Jobs">Job</Nav.Link>
                                <Nav.Link href="#">Masjid</Nav.Link>
                                <Nav.Link href="/MainPage">Main Page</Nav.Link>
                            </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
              </div>
            </div>
            <div className="col-md-2">
              <div className="headRight">
                <button className="searchBtn"><i className="far fa-search"></i></button>
                <a href="/Login" className="themeBtn">Login <i className="fal fa-long-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
