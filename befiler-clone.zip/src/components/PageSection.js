import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import Page from '../assets/images/pg-1.png'


const PageSection = () => {

    const settings = {
        dots: false,             
        infinite: true,         
        speed: 500,             
        slidesToShow: 1,        
        slidesToScroll: 1,      
        autoplay: true,         
        autoplaySpeed: 2000,    
    };

  return (

    <section className="page-sect">
        <div className="container-fluid p-0">
            <div className="row m-0 justify-content-center">
                <div className="col-md-10 p-0">
                    <div className="supCont">
                        <h4>Our Page</h4>
                    </div>
                </div>
            </div>
            <div className="row m-0">
                <div className="col-md-12 p-0">
                    <div className="pageSlider">
                        <Slider {...settings}>
                            <figure><img src={Page} alt="Consultants" className="img-fluid w-100" /></figure>
                            <figure><img src={Page} alt="Consultants" className="img-fluid w-100" /></figure>
                            <figure><img src={Page} alt="Consultants" className="img-fluid w-100" /></figure>
                            <figure><img src={Page} alt="Consultants" className="img-fluid w-100" /></figure>
                        </Slider>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default PageSection;