import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
// In src/index.js or src/App.js
import '@fortawesome/fontawesome-free/css/all.min.css';

import Wave from '../assets/images/wave.png'
import vidOne from '../assets/images/vid-1.png'
import vidTwo from '../assets/images/vid-2.png'
import vidThree from '../assets/images/vid-3.png'

const VideoSection = () => {
  return (
    <section className="video-sect">
        <img src={Wave} alt="Consultants" className="img-fluid w-100 wave" />
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    <div className="vidCont">
                        <figure>
                            <img src={vidOne} alt="Consultants" className="img-fluid w-100" />
                            <div className="overlay">
                                <a href="javascript:;" className="youBtn"><i className="fab fa-youtube"></i></a>
                            </div>
                        </figure>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="vid-double">
                        <div className="vidCont">
                            <figure>
                                <img src={vidTwo} alt="Consultants" className="img-fluid w-100" />
                                <div className="overlay">
                                    <a href="javascript:;" className="youBtn"><i className="fab fa-youtube"></i></a>
                                </div>
                            </figure>
                        </div>
                        <div className="vidCont">
                            <figure>
                                <img src={vidTwo} alt="Consultants" className="img-fluid w-100" />
                                <div className="overlay">
                                    <a href="javascript:;" className="youBtn"><i className="fab fa-youtube"></i></a>
                                </div>
                            </figure>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="vidCont">
                        <figure>
                            <img src={vidThree} alt="Consultants" className="img-fluid w-100" />
                            <div className="overlay">
                                <a href="javascript:;" className="youBtn"><i className="fab fa-youtube"></i></a>
                            </div>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default VideoSection;