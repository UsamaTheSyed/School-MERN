import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import Wave from '../assets/images/wave.png'
import stImg from '../assets/images/stImg-1.png'

const BrightStudent = () => {

  return (
    <section className="star-sect">
        <img src={Wave} alt="Consultants" className="img-fluid wave" />
        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="subtitle">Meet with our stars</h3>
                    <h2 className="sectionHeading">Our Bright Students</h2>
                </div>
            </div>
            <div className="row">


                <div className="col-md-4">
                    <div className="strCard">
                        <figure>
                            <img src={stImg} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <h3>Student name </h3>
                        <p>Nulla a auctor leo. Vestibulum viverra mattis arcu
                            nec viverra. Vivamus</p>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="strCard">
                        <figure>
                            <img src={stImg} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <h3>Student name </h3>
                        <p>Nulla a auctor leo. Vestibulum viverra mattis arcu
                            nec viverra. Vivamus</p>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="strCard">
                        <figure>
                            <img src={stImg} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <h3>Student name </h3>
                        <p>Nulla a auctor leo. Vestibulum viverra mattis arcu
                            nec viverra. Vivamus</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default BrightStudent;