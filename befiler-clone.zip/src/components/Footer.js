import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
// In src/index.js or src/App.js
import '@fortawesome/fontawesome-free/css/all.min.css';

import Ftop from '../assets/images/footer-top.png'
import FLast from '../assets/images/footLast.png'
import Zebra from '../assets/images/zebra.png'
import Frame from '../assets/images/frame2.png'
import Phone from '../assets/images/phone.png'
import Mail from '../assets/images/mail.png'
import Maps from '../assets/images/map.png'
import Logo from '../assets/images/logo.png'
import BlogTwo from '../assets/images/blg-2.png'
import BlogThree from '../assets/images/blg-3.png'

const Footer = () => {

  return (
    <footer>
        <img src={Ftop} alt="Consultants" className="img-fluid footer-top" />
        <img src={FLast} alt="Consultants" className="img-fluid footLast" />
        <img src={Zebra} alt="Consultants" className="img-fluid zebra" />
        <img src={Frame} alt="Consultants" className="img-fluid frame2" />

        <div className="container">
            <div className="row justify-content-center">
                <div className="col-md-10">
                    <div className="footOne">
                        <div className="row justify-content-center">
                            <div className="col-md-4">
                                <div className="cntLink">
                                    <a href="tel:+000-555-0112">
                                        <figure>
                                            <img src={Phone} alt="Consultants" className="img-fluid" />
                                        </figure>
                                        <span>
                                            <h5>Call Us 7/24</h5>
                                            <h4>+000-555-0112</h4>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="cntLink">
                                    <a href="mailto:info@gmail.com">
                                        <figure>
                                            <img src={Mail} alt="Consultants" className="img-fluid" />
                                        </figure>
                                        <span>
                                            <h5>Make a Quote</h5>
                                            <h4>info@gmail.com</h4>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="cntLink">
                                    <a href="javascript:;">
                                        <figure>
                                            <img src={Maps} alt="Consultants" className="img-fluid" />
                                        </figure>
                                        <span>
                                            <h5>Location</h5>
                                            <h4>4517 abc PAK</h4>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="foot-Two">
                        <div className="row justify-content-between">
                            <div className="col-md-3">
                                <div className="footCont">
                                    <a href="index.php">
                                        <img src={Logo} alt="Consultants" className="img-fluid" />
                                    </a>
                                    <p>
                                        Phasellus ultricies aliquam volutpat
                                        ullamcorper laoreet neque, a lacinia
                                        curabitur lacinia mollis
                                    </p>
                                    <ul className="iconLink">
                                        <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                                        <li><a href="javascript:;"><i className="fab fa-twitter"></i></a></li>
                                        <li><a href="javascript:;"><i className="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="javascript:;"><i className="fab fa-youtube"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-md-2">
                                <div className="footCont">
                                    <h4>Quick Links</h4>
                                    <ul className="quickLinks">
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> Our Services</a>
                                        </li>
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> Our Blogs</a></li>
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> FAQ’S</a></li>
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-md-2">
                                <div className="footCont">
                                    <h4>Categories</h4>
                                    <ul className="quickLinks">
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> Services</a>
                                        </li>
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> Our Blogs</a></li>
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> FAQ’S</a></li>
                                        <li><a href="javascript:;"><i className="far fa-chevron-right"></i> Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="footCont">
                                    <h4>Recent Posts</h4>
                                    <ul className="blgList">
                                        <li>
                                            <a href="javascript:;">
                                                <figure>
                                                    <img src={BlogTwo} alt="Consultants" className="img-fluid" />
                                                </figure>
                                                <div>
                                                    <span><i className="fas fa-calendar-alt"></i> 20 Feb, 2024</span>
                                                    <h4>That jerk Form Finance
                                                        really threw me</h4>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <figure>
                                                    <img src={BlogThree} alt="Consultants" className="img-fluid" />
                                                </figure>
                                                <div>
                                                    <span><i className="fas fa-calendar-alt"></i> 20 Feb, 2024</span>
                                                    <h4>That jerk Form Finance
                                                        really threw me</h4>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row align-items-center">
                        <div className="col-md-6">
                            <div className="ftLast">
                                <p>© All Copyright {new Date().getFullYear()} by <a href="javascript:;">School Web 360</a></p>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="ftLast">
                                <ul>
                                    <li><a href="javascript:;">Terms & Condition</a></li>
                                    <li><a href="javascript:;">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
  );
};

export default Footer;
