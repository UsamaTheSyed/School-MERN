import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import fcOne from '../assets/images/fc-1.png'
import fcTwo from '../assets/images/fc-2.png'
import fcThree from '../assets/images/fc-3.png'
import fcFour from '../assets/images/fc-4.png'

const Facilities = () => {


    const cardData = [
        {
          title: 'Playground',
          description: 'In a free hour, when our power of choice is untrammeled and',
          image: fcOne,
        },
        {
          title: 'Playground',
          description: 'In a free hour, when our power of choice is untrammeled and',
          image: fcTwo,
        },
        {
          title: 'Playground',
          description: 'In a free hour, when our power of choice is untrammeled and',
          image: fcThree,
        },
        {
          title: 'Playground',
          description: 'In a free hour, when our power of choice is untrammeled and',
          image: fcFour,
        }
    ];


  return (
    <section className="facil-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div className="supCont">
                        <h4>School Facilitates</h4>
                    </div>
                </div>
            </div>
            <div className="row">
                {cardData.map((card, index) => (
                    <div className="col-md-3">
                        <div className="fclCard fclEven">
                            <figure>
                                <img src={card.image} alt={card.title} className="img-fluid" />
                            </figure>
                            <h3>{card.title}</h3>
                            <p>{card.description}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </section>                  
  );
};

export default Facilities;