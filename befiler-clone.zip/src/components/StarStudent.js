import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import Student from '../assets/images/stu-1.png'
import Shape from '../assets/images/stu-shape.png'


const StarStudent = () => {

  return (
    <section className="student-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="subtitle">Positions</h3>
                    <h2 className="sectionHeading">Star Students</h2>
                </div>
            </div>
            <div className="row">
                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>


                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>


                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>

                <div className="col-md-3">
                    <div className="stuCard">
                        <figure>
                            <img src={Student} alt="Consultants" className="img-fluid w-100" />
                            <img src={Shape} alt="Consultants" className="img-fluid stu-shape" />
                        </figure>
                        <h3>POSITION 1</h3>
                        <h4>Brooklyn Simmons</h4>
                        <p>Class 1</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default StarStudent;