import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import qtOne from '../assets/images/qtOne.png'
import qtTwo from '../assets/images/qtTwo.png'
import qtThree from '../assets/images/qtThree.png'

const Testimonials = () => {

    const settings = {
        dots: false,             
        infinite: true,         
        speed: 500,             
        slidesToShow: 3,        
        slidesToScroll: 1,      
        autoplay: true,         
        autoplaySpeed: 2000,    
      };
  return (
    <section className="test-sect">
        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="subtitle">testimonials</h3>
                    <h2 className="sectionHeading">People words are the key<br/>
                        to happy kids</h2>
                </div>
            </div>
            <div className="row">
                <div className="col-md-12">
                    <div className="testSlider slick-slider-container">
                        <Slider {...settings}>
                            <div className="tstCont one">
                                <img src={qtOne} alt="Consultants" className="qoute" />
                                <p>Corquent per conubia nostra, per inceptos
                                    himenaeos. Suspendisse gravida vitae nisi
                                    Class aptent taciti sociosqu ad litora</p>
                                <h5>Wade Warren</h5>
                            </div>
                            <div className="tstCont two">
                                <img src={qtTwo} alt="Consultants" className="qoute" />
                                <p>Corquent per conubia nostra, per inceptos
                                    himenaeos. Suspendisse gravida vitae nisi
                                    Class aptent taciti sociosqu ad litora</p>
                                <h5>Wade Warren</h5>
                            </div>
                            <div className="tstCont three">
                                <img src={qtThree} alt="Consultants" className="qoute" />
                                <p>Corquent per conubia nostra, per inceptos
                                    himenaeos. Suspendisse gravida vitae nisi
                                    Class aptent taciti sociosqu ad litora</p>
                                <h5>Wade Warren</h5>
                            </div>
                            <div className="tstCont two">
                                <img src={qtTwo} alt="Consultants" className="qoute" />
                                <p>Corquent per conubia nostra, per inceptos
                                    himenaeos. Suspendisse gravida vitae nisi
                                    Class aptent taciti sociosqu ad litora</p>
                                <h5>Wade Warren</h5>
                            </div>
                            <div className="tstCont three">
                                <img src={qtThree} alt="Consultants" className="qoute" />
                                <p>Corquent per conubia nostra, per inceptos
                                    himenaeos. Suspendisse gravida vitae nisi
                                    Class aptent taciti sociosqu ad litora</p>
                                <h5>Wade Warren</h5>
                            </div>
                        </Slider>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};

export default Testimonials;