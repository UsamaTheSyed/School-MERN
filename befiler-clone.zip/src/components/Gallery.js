import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import Botshape from '../assets/images/gl-bottom-shape.png'
import Topshape from '../assets/images/gl-top-shape.png'
import GlOne from '../assets/images/gal-1.png'
import GlTwo from '../assets/images/gal-2.png'
import GlThree from '../assets/images/gal-3.png'
import GlFour from '../assets/images/gal-4.png'
import GlFive from '../assets/images/gal-5.png'



const Gallery = () => {

    const settings = {
        dots: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 5000,
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: false,
        variablewidth: true,
        centerMode: true,         
    };

    const cardData = [
        { image: GlOne},
        { image: GlTwo},
        { image: GlThree},
        { image: GlFour},
        { image: GlFive},
    ];


  return (
    <section className="gallery-sect">
        <img src={Botshape} alt="Consultants" className="img-fluid gl-bottom-shape" />
        <img src={Topshape} alt="Consultants" className="img-fluid gl-top-shape" />
        i <div className="container-fluid p-0">
            <div className="row m-0">
                <div className="col-md-12 p-0">
                    <div className="galSlider slick-slider-container">
                        <Slider {...settings}>
                            {cardData.map((card, index) => (
                                <figure>
                                    <img src={card.image} alt={card.title} className="img-fluid w-100" />
                                </figure>
                            ))}

                        </Slider>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default Gallery;