import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import BlogOne from '../assets/images/blg-1.png'
import BlogTwo from '../assets/images/blg-2.png'
import BlogThree from '../assets/images/blg-3.png'

import ProfOne from '../assets/images/ba-1.png'
import ProfTwo from '../assets/images/ba-2.png'

const BlogSection = () => {

  return (
    
      
    <section className="blog-sect">
        <div className="container">
            <div className="row align-items-center">
                <div className="col-md-6">
                    <h3 className="subtitle">Upcoming Events</h3>
                    <h2 className="sectionHeading">Explore New Events</h2>
                </div>
                <div className="col-md-6">
                    <div className="headerBtn">
                        <a href="javascript:;" className="themeBtn">See All Article <i
                                className="fal fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-md-6">
                    <div className="blgCard">
                        <figure>
                            <img src={BlogOne} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <div className="blgBody">
                            <ul>
                                <li><a href="javascript:;"><i className="fas fa-tag"></i> Cooking</a></li>
                                <li><a href="javascript:;"><i className="fas fa-calendar-alt"></i> Feb 20, 2024</a></li>
                            </ul>
                            <h3><a href="javascript:;">Questions to Ask Vendors Before Choosing an
                                    LMS Platform</a></h3>
                            <p>
                                Phasellus turpis sapien, venenatis tempus vestibulum in, cursus quis enim. Nunc
                                mollis vitae ipsum sit amet ultrices. Duis in dapibus erat
                            </p>
                            <div className="blg-foot">
                                <div className="adminCont">
                                    <figure><img src={ProfOne} alt="Consultants" className="img-fluid" /></figure>
                                    <div>
                                        <h5>By Admin</h5>
                                        <h6>Ronald Richards</h6>
                                    </div>
                                </div>
                                <div className="headerBtn">
                                    <a href="javascript:;" className="themeBtn">Read More <i
                                            className="fal fa-long-arrow-right"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="blgCard blgFlex">
                        <figure>
                            <img src={BlogTwo} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <div className="blgBody">
                            <ul>
                                <li><a href="javascript:;"><i className="fas fa-tag"></i> Cooking</a></li>
                                <li><a href="javascript:;"><i className="fas fa-calendar-alt"></i> Feb 20, 2024</a></li>
                            </ul>
                            <h3><a href="javascript:;">That jerk Form Finance really threw me</a></h3>
                            <div className="blg-foot">
                                <div className="adminCont">
                                    <figure><img src={ProfTwo} alt="Consultants" className="img-fluid" /></figure>
                                    <div>
                                        <h5>By Admin</h5>
                                        <h6>Dianne Russell</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="blgCard blgFlex">
                        <figure>
                            <img src={BlogThree} alt="Consultants" className="img-fluid w-100" />
                        </figure>
                        <div className="blgBody">
                            <ul>
                                <li><a href="javascript:;"><i className="fas fa-tag"></i> Cooking</a></li>
                                <li><a href="javascript:;"><i className="fas fa-calendar-alt"></i> Feb 20, 2024</a></li>
                            </ul>
                            <h3><a href="javascript:;">That jerk Form Finance really threw me</a></h3>
                            <div className="blg-foot">
                                <div className="adminCont">
                                    <figure><img src={ProfOne} alt="Consultants" className="img-fluid" /></figure>
                                    <div>
                                        <h5>By Admin</h5>
                                        <h6>Dianne Russell</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
  );
};

export default BlogSection;
