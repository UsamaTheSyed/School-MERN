import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import Chairman from "../assets/images/chairman.png";
import School from "../assets/images/school.png";
import Level from '../assets/images/level.png'
import Dates from '../assets/images/date.png'
import frcImg from '../assets/images/frcImg.png'
import frcShape from '../assets/images/frcShape.png'

const IntroSection = () => {

    const settings = {
        dots: false,             
        infinite: true,         
        speed: 500,             
        slidesToShow: 1,        
        slidesToScroll: 1,      
        autoplay: true,         
        autoplaySpeed: 2000,    
    };

  return (
    <div>
        <section className="intro-sect">
            <div className="container">
                <div className="row">
                    <div className="col-md-8">
                        <h3 className="subtitle">Intro</h3>
                        <h2 className="sectionHeading">introduction to PPSA School</h2>
                        <div className="introSlider slick-slider-container">
                            <Slider {...settings}>
                                <div className="introCont">
                                    <div className="chairmain">
                                        <div className="introCard">
                                            <figure>
                                                <img src={Chairman} alt="Consultants" className="img-fluid w-100" />
                                            </figure>
                                            <h6><i className="fas fa-map-marker-alt"></i> Abc School Elgin St. Celina, Pak</h6>
                                            <h4>Chairman</h4>
                                            <p>School Name</p>
                                        </div>
                                        <div className="schoolCard">
                                            <figure>
                                                <img src={School} alt="Consultants" className="img-fluid w-100" />
                                            </figure>
                                            <h4>School Name</h4>
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industrLorem
                                                Ipsum is simply dummy text of the printing and typesetting industry Lorem
                                                Ipsum is
                                                simply dummy text of the printing and typesetting industryy</p>
                                        </div>
                                    </div>
                                    <div className="introLast">
                                        <div className="introBtn">
                                            <a href="javascript:;" className="themeBtn">About School <i
                                                    className="fal fa-long-arrow-right"></i></a>
                                        </div>
                                        <div className="introRev">
                                            <h5>(10 Review)</h5>
                                            <span>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div className="introCont">
                                    <div className="chairmain">
                                        <div className="introCard">
                                            <figure>
                                                <img src={Chairman} alt="Consultants" className="img-fluid w-100" />
                                            </figure>
                                            <h6><i className="fas fa-map-marker-alt"></i> Abc School Elgin St. Celina, Pak</h6>
                                            <h4>Chairman</h4>
                                            <p>School Name</p>
                                        </div>
                                        <div className="schoolCard">
                                            <figure>
                                                <img src={School} alt="Consultants" className="img-fluid w-100" />
                                            </figure>
                                            <h4>School Name</h4>
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industrLorem
                                                Ipsum is simply dummy text of the printing and typesetting industry Lorem
                                                Ipsum is
                                                simply dummy text of the printing and typesetting industryy</p>
                                        </div>
                                    </div>
                                    <div className="introLast">
                                        <div className="introBtn">
                                            <a href="javascript:;" className="themeBtn">About School <i
                                                    className="fal fa-long-arrow-right"></i></a>
                                        </div>
                                        <div className="introRev">
                                            <h5>(10 Review)</h5>
                                            <span>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                                <i className="fas fa-star"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </Slider>
                            
                        </div>
                        <div className="introsldBtn">
                            <button className="intNext"><i className="fal fa-long-arrow-right"></i></button>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="intros-chlCont">
                            <div className="schlCont">
                                <form>
                                    <div className="form-row align-items-center justify-content-between">
                                        <div className="col-md-4">
                                            <div className="input-group">
                                                <div className="input-group-prepend">
                                                    <div className="input-group-text">
                                                        <img src={Level} alt="Consultants" className="img-fluid" />
                                                    </div>
                                                </div>
                                                <input type="text" className="form-control" id="inlineFormInputGroup"
                                                    placeholder="Enter the Name" />
                                            </div>
                                        </div>
                                        <div className="col-md-5">
                                            <div className="input-group">
                                                <div className="input-group-prepend">
                                                    <div className="input-group-text">
                                                        <img src={Dates} alt="Consultants" className="img-fluid" />
                                                    </div>
                                                </div>
                                                <input type="text" className="form-control" id="inlineFormInputGroup"
                                                    placeholder="Choose Date" />
                                            </div>
                                        </div>
                                        <div className="col-md-3">
                                            <button type="submit" className="themeBtn">Explore</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <p><i className="fas fa-star"></i> 1st Friend ship scout in Karachi Gulshan e Iqbal
                                organized by PPSA</p>

                            <div className="frCard">
                                <figure>
                                    <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                    <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                    <div className="overlay">
                                        <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                            Jan 16, 2024</a>
                                    </div>
                                </figure>
                            </div>


                            <p><i className="fas fa-star"></i> 1st Friend ship scout in Karachi Gulshan e Iqbal
                                organized by PPSA</p>

                            <div className="frCard">
                                <figure>
                                    <img src={frcImg} alt="Consultants" className="img-fluid w-100" />
                                    <img src={frcShape} alt="Consultants" className="img-fluid frcShape" />
                                    <div className="overlay">
                                        <a href="javascript:;" className="dateBtn"><i className="fas fa-calendar-alt"></i>
                                            Jan 16, 2024</a>
                                    </div>
                                </figure>
                            </div>


                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>
  );
};

export default IntroSection;