import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

const StarBanner = () => {

  return (
    <section className="positionBanner">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div className="posCont">
                        <h2>Position Holders</h2>
                        <ul>
                            <li><a href="javascript:;">Home</a></li>
                            <li><a href="javascript:;">Position</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
  );
};

export default StarBanner;