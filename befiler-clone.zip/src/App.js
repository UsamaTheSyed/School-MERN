import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { useState, createContext, useContext } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
// In src/index.js or src/App.js
import '@fortawesome/fontawesome-free/css/all.min.css';

import Home from "./pages/Home";
import StarStudents from "./pages/StarStudents";
import WelcomePage from "./pages/WelcomePage";
import Chairman from './pages/Chairman';
import FinalSchool from "./pages/FinalSchool";
import MainPage from './pages/MainPage';
import Jobs from './pages/Jobs';
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Signup from "./pages/Signup";

export const AuthContext = createContext();

const PrivateRoute = ({ children }) => {
  const { user } = useContext(AuthContext);
  return user ? children : <Navigate to="/login" />;
};

export default function App() {
  const [user, setUser] = useState(null);

  return (
    <AuthContext.Provider value={{ user, setUser }}>
      <Router>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/StarStudents" element={<StarStudents />} />
          <Route path="/WelcomePage" element={<WelcomePage />} />
          <Route path="/Chairman" element={<Chairman />} />
          <Route path="/FinalSchool" element={<FinalSchool />} />
          <Route path="/MainPage" element={<MainPage />} />
          <Route path="/Jobs" element={<Jobs />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Signup" element={<Signup />} />
          <Route
            path="/dashboard"
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            }
          />
        </Routes>
        <Footer />
      </Router>
    </AuthContext.Provider>
  );
}