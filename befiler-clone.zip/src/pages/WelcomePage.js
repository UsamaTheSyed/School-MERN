
import Bannerslider from "../components/Bannerslider";
import FractionSection from "../components/FractionSection";
import PageSection from "../components/PageSection";
import SupportSection from "../components/SupportSection";
import TeamSection from "../components/TeamSection";

export default function WelcomePage() {
  return (
    <div>
      <Bannerslider />

      <FractionSection />
      <PageSection />
      <SupportSection />
      <TeamSection />
    </div>
  );
}
