import BlogSection from "../components/BlogSection";
import HeroSection from "../components/HeroSection";
import PageSection from "../components/PageSection";
import SupportSection from "../components/SupportSection";
import TeamSection from "../components/TeamSection";
import VideoSection from "../components/VideoSection";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <VideoSection />
      <SupportSection />
      <PageSection />
      <TeamSection />
      <BlogSection />
    </div>
  );
}
