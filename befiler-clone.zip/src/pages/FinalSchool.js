import Facilities from "../components/Facilities";
import FinalBanner from "../components/FinalBanner";
import Event from "../components/Event";
import PositionHolder from "../components/PositionHolder";
import TeamTwo from "../components/TeamTwo";
import VideoSection from "../components/VideoSection";
import BlogSection from "../components/BlogSection";
import Testimonials from "../components/Testimonials";
import Count from "../components/Count";
import Location from "../components/Location";
import Opportunity from "../components/Opportunity";

export default function FinalSchool() {
  return (
    <div>
        <FinalBanner />
        <Facilities />
        <Event />
        <PositionHolder />
        <TeamTwo />
        <VideoSection />
        <BlogSection />
        <Opportunity />
        <Testimonials />
        <Count />
        <Location />
    </div>
  );
}
