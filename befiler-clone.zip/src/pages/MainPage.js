
import DifferSection from "../components/DifferSection";
import Gallery from "../components/Gallery";
import MainPgBanner from "../components/MainPgBanner";
import TeamSection from "../components/TeamSection";


export default function MainPage() {
  return (
    <div>
      <MainPgBanner />
      <DifferSection />
      <TeamSection />
      <Gallery />
    </div>
  );
}
