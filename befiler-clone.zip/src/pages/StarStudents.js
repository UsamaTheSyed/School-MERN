import StarBanner from "../components/StarBanner";
import StarStudent from "../components/StarStudent";

export default function StarStudents() {
  return (
    <div>
        <StarBanner />
        <StarStudent />
    </div>
  );
}
