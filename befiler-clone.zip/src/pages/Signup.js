import Registration from "../components/Registration";


export default function Signup() {
  return (
    <div>
        <Registration />
    </div>
  );
}
