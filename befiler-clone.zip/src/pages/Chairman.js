
import Bannerslider from "../components/Bannerslider";
import BrightStudent from "../components/BrightStudent";
import Innovation from "../components/Innovation";
import IntroSection from "../components/IntroSection";
import StarStudent from "../components/StarStudent";
import TeamTwo from "../components/TeamTwo";
import Testimonials from "../components/Testimonials";

export default function Chairman() {
  return (
    <div>
        <Bannerslider />
        <IntroSection />
        <TeamTwo />
        <BrightStudent />
        <Testimonials />
        <StarStudent />
        <Innovation />
    </div>
  );
}