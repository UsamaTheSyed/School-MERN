import MainPgBanner from "../components/MainPgBanner";
import Opportunity from "../components/Opportunity";
import StudentSection from "../components/StudentSection";
import TeamSection from "../components/TeamSection";


export default function Jobs() {
  return (
    <div>
        <MainPgBanner />
        <Opportunity />
        <StudentSection />
        <TeamSection />
    </div>
  );
}
