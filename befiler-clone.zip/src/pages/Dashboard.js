// pages/Dashboard.js
export default function Dashboard() {
    return (
      <div className="p-6">
        <h2 className="text-3xl font-bold">Dashboard</h2>
        <p className="mt-2">Welcome to your tax filing dashboard. Upload documents, check status, and file your returns.</p>
      </div>
    );
  }
  