// pages/Login.js
import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../App";

export default function Login() {
  const { setUser } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    if (email && password) {
      setUser({ email });
      navigate("/dashboard");
    }
  };

  return (
        <section className="regis-sect">
          <div className="container">
              <div className="row justify-content-center">
                  <div className="col-md-6">
                      <div className="regForm">
                          <h3>Login Here</h3>
                          <form>
                              <div className="form-row">
                                  <div className="form-group col-md-12">
                                      <input type="email" className="form-control" placeholder="Email*" value={email} onChange={(e) => setEmail(e.target.value)} />
                                  </div>
                                  <div className="form-group col-md-12">
                                      <input type="password" placeholder="Password*" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} />
                                  </div>
                              </div>

                              <div className="formSign headRight">
                                <button onClick={handleLogin} className="themeBtn">Login</button>
                                <a href="/Signup" className="themeBtn">Sign up</a>
                              </div>
                              <ul>
                                  <li><a href="javascript:;"><i className="fab fa-google"></i></a></li>
                                  <li><a href="javascript:;"><i className="fab fa-facebook-f"></i></a></li>
                              </ul>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
        </section>

  );
}